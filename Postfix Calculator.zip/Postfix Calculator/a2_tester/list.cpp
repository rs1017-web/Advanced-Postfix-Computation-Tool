#include "list.h"
#include "node.h"
#include <iostream>
using namespace std;

List :: List(){
    sentinel_head = new Node(true);
    sentinel_tail=new Node(true);
    sentinel_head->next=sentinel_tail;
    sentinel_tail->prev=sentinel_head;
    size=0;
    // sentinel_head->prev=nullptr;
    // sentinel_tail->next=nullptr;
}

List:: ~List(){
    // DESTRUCTOR OF LIST IS CALLED
    Node* curr_node=sentinel_head;
    while (curr_node!=nullptr){
        Node* temp=curr_node->next;
        delete curr_node;
        curr_node=temp;
    }
    // delete sentinel_head;
    // delete sentinel_tail;
}

Node* List :: get_head(){
    return sentinel_head;
}

int List :: delete_tail(){    //inn sab mein error daal dena
        Node* temp= sentinel_tail->prev;
        if (temp->is_sentinel_node()){
            throw runtime_error("Empty Stack");
        }
        int ans= temp->get_value();      // DOUBT : WHY THIS LINE IS NOT GIVING ANY ERROR AFTER USING temp->get_value??
        Node* last_to_last=temp->prev;
        last_to_last->next=sentinel_tail;
        sentinel_tail->prev=last_to_last;
        delete temp;
        return ans;

}

int List :: get_size(){
    Node* curr_node=sentinel_head->next;
    int count=0;
    while (!curr_node->is_sentinel_node()){
        curr_node=curr_node->next;
        count++;
    }
    return count;
} 

void List :: insert(int v){
    // cout<<"insert done"<<endl;
    Node* new_node = new Node (v,sentinel_tail,sentinel_tail->prev);
    sentinel_tail->prev=new_node;
    new_node->prev->next=new_node;
}

