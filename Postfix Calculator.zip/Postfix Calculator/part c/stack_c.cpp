#include "node.h"
#include "list.h"
#include "stack_c.h"
#include <iostream>
using namespace std;

Stack_C::Stack_C(){
    stk= new List();
    cout<<"constructor"<<endl;
}


Stack_C :: ~Stack_C(){
    delete stk;
}


void Stack_C :: push (int data){
    stk->insert(data);
    // List listobj;
    // listobj.insert(data);
}

int Stack_C :: pop(){
    int ele = stk->delete_tail(); // Use the List instance for delete_tail
    return ele;
    // List listobj;
    // int ele=listobj.delete_tail(); 
    // return ele;
}

int Stack_C :: get_element_from_top(int idx){
    List listobj;
    Node* curr_node=listobj.get_head()->next;
    int count=0;
    while (curr_node!=nullptr){
        if (count==idx){
            return curr_node->get_value();
        }
        curr_node=curr_node->next;
        count++;
    }
    throw runtime_error("Index out of range");
}


int Stack_C :: get_element_from_bottom(int idx){
    List listobj;
    Node* curr_node=listobj.get_head()->next;
    int count=0;
    while (curr_node!=nullptr){
        if (count==idx){
            return curr_node->get_value();
        }
        curr_node=curr_node->next;
        count++;
    }
    throw runtime_error("Index out of range");   
}

void Stack_C :: print_stack (bool top_or_bottom){
    if (!top_or_bottom){
        List listobj;
        Node* curr_node=listobj.get_head()->next;
        while (curr_node!=NULL){
            cout<<curr_node->get_value()<<endl;
            curr_node=curr_node->next;
        }
    }
    else{
        cout<<"tail se start karna hai"<<endl;
    }
}

int Stack_C :: add(){
    int ele1=pop();
    int ele2=pop();
    int addition=ele1+ele2;
    push(addition);
    return addition;
}

int Stack_C :: subtract(){
    int ele1=pop();
    int ele2=pop();
    int subt=ele2-ele1;  //Ek baar check ki ele1-ele2 hai yaa ye sahi hai
    push(subt);
    return subt;
}

int Stack_C :: multiply(){
    int ele1=pop();
    int ele2=pop();
    int mul=ele2*ele1;
    push(mul);
    return mul;    
}

int Stack_C :: divide(){
    int ele1=pop();
    int ele2=pop();
    int res=ele2/ele1;   // REMEMBER TO MAKE UT FLOOR BEFORE PUSHING
    push(res);
    return res;   
}

List* Stack_C :: get_stack(){
    return stk;
}

int Stack_C :: get_size(){
    cout<<"size ka function pura karna"<<endl;
    return 177;
}
