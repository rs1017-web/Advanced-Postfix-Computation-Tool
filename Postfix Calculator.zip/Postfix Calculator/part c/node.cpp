#include "node.h"
#include <iostream>
using namespace std;

Node :: Node(bool sentinel){
    if (sentinel){
        Node* new_node= new Node();
        new_node->value=0;
        new_node->next=nullptr;
        new_node->prev=nullptr;
    }
}

bool Node :: is_sentinel_node(){
    return is_sentinel;
}

Node ::  Node(int v, Node* nxt, Node* prv){
    Node* new_node= new Node();
    new_node->value=v;
    new_node->next=nxt;
    new_node->prev=prv;
}

int Node :: get_value(){
    return value;
}