#include <iostream>
#include <cmath>
using namespace std;

class Node {
private: 
    int value;
    bool is_sentinel;

public: 
    Node* next;
    Node* prev;

    // Use to construct a sentinel node (see list.h)
    Node(bool sentinel=true);   

    // Use to construct a regular node
    Node(int v, Node* nxt, Node* prv);

    // Return whether a node is a sentinel node 
    // Use it to check if we are at the ends of a list
    bool is_sentinel_node();

    // Return the value of a node
    int get_value();
};


Node :: Node(bool sentinel){
        // cout<<"hi"<<endl;
        value=0;
        next=nullptr;
        prev=nullptr;
        is_sentinel=true;
}

Node ::  Node(int v, Node* nxt, Node* prv){
    value=v;
    next=nxt;
    prev=prv;
    is_sentinel=false;
}

bool Node :: is_sentinel_node(){
    return is_sentinel;
}


int Node :: get_value(){
    return value;
}


class List {
private: 
    int size;
    Node* sentinel_head;
    Node* sentinel_tail;

public: 
    List();

    ~List();

    // Insert an element at the tail of the linked list 
    void insert(int v);

    // Delete the tail of the linked list and return the value
    // You need to delete the valid tail element, not the sentinel
    int delete_tail();

    // Return the size of the linked list 
    // Do not count the sentinel elements
    int get_size(); 

    // Return a pointer to the sentinel head of the linked list 
    Node* get_head();

};

List :: List(){
    sentinel_head = new Node(true);
    sentinel_tail=new Node(true);
    sentinel_head->next=sentinel_tail;
    sentinel_tail->prev=sentinel_head;
    size=0;
    // sentinel_head->prev=nullptr;
    // sentinel_tail->next=nullptr;
}

List:: ~List(){
    // DESTRUCTOR OF LIST IS CALLED
    Node* curr_node=sentinel_head;
    while (curr_node!=nullptr){
        Node* temp=curr_node->next;
        delete curr_node;
        curr_node=temp;
    }
    // delete sentinel_head;
    // delete sentinel_tail;
}

Node* List :: get_head(){
    return sentinel_head;
}

int List :: delete_tail(){
        Node* temp= sentinel_tail->prev;
        if (temp->is_sentinel_node()){
            throw runtime_error("Empty Stack");
        }
        int ans= temp->get_value();      // DOUBT : WHY THIS LINE IS NOT GIVING ANY ERROR AFTER USING temp->get_value??
        Node* last_to_last=temp->prev;
        last_to_last->next=sentinel_tail;
        sentinel_tail->prev=last_to_last;
        delete temp;
        return ans;

}

int List :: get_size(){
    Node* curr_node=sentinel_head->next;
    int count=0;
    while (!curr_node->is_sentinel_node()){
        curr_node=curr_node->next;
        count++;
    }
    return count;
} 

void List :: insert(int v){
    // cout<<"insert done"<<endl;
    Node* new_node = new Node (v,sentinel_tail,sentinel_tail->prev);
    sentinel_tail->prev=new_node;
    new_node->prev->next=new_node;
}

class Stack_C {
private:
    List* stk; // The linked list

public: 
    // Constructor
    Stack_C();

    // Destructor
    ~Stack_C();

    void push(int data);

    int pop();

    int get_element_from_top(int idx);

    int get_element_from_bottom(int idx);

    void print_stack(bool top_or_bottom);

    int add();

    int subtract();

    int multiply();

    int divide(); 

    List* get_stack(); // Get a pointer to the linked list representing the stack

    int get_size(); // Get the size of the stack
};

Stack_C::Stack_C(){
    stk = new List();
    // cout<<"constructor"<<endl;
}


Stack_C :: ~Stack_C(){
    delete stk;
}


void Stack_C :: push (int data){
    // cout<<"element pushed"<<endl;
    // List lstobj;
    stk->insert(data);
    // List listobj;
    // listobj.insert(data);
}

int Stack_C :: pop(){
    // List lstobj;
    // int size = stk->get_size();
    // if (size==0){
    //     throw runtime_error("Empty Stack");
    // }
    int ele = stk->delete_tail(); // Use the List instance for delete_tail
    return ele;
    // List listobj;
    // int ele=listobj.delete_tail(); 
    // return ele;
}

int Stack_C :: get_element_from_top(int idx){
    Node* curr_node=stk->get_head()->next;  //yha bhi change kiya hai.
    Node* sentinel_tail;
    while (!curr_node->is_sentinel_node()){
        curr_node=curr_node->next;
        if (curr_node->is_sentinel_node()){
            sentinel_tail=curr_node;
            break;
        }
    }
    Node* new_node=sentinel_tail->prev;
    int count=0;
    while (!new_node->is_sentinel_node()){
        if (count==idx){
            return new_node->get_value();
        }
        // cout<<new_node->get_value()<<endl;
        count++;
        new_node=new_node->prev;
    }
    throw runtime_error("Index out of range");
}


int Stack_C :: get_element_from_bottom(int idx){
    // List listobj;
    Node* curr_node=stk->get_head()->next;   //yha bhi change kiya hai.
    int count=0;
    while (!curr_node->is_sentinel_node()){
        if (count==idx){
            return curr_node->get_value();
        }
        curr_node=curr_node->next;
        count++;
    }
    throw runtime_error("Index out of range");   
}

void Stack_C :: print_stack (bool top_or_bottom){
    if (!top_or_bottom){
        Node* curr_node=stk->get_head()->next;  //Yha pe changes kiye hai.
        while (curr_node!=NULL){
            cout<<curr_node->get_value()<<endl;
            curr_node=curr_node->next;
        }
    }
    else{
        Node* curr_node=stk->get_head()->next;     //yha bhi change kiya hai.
        Node* sentinel_tail;
        while (!curr_node->is_sentinel_node()){
            curr_node=curr_node->next;
            if (curr_node->is_sentinel_node()){
                sentinel_tail=curr_node;
                break;
            }
        }
        Node* new_node=sentinel_tail->prev;
        while (!new_node->is_sentinel_node()){
            cout<<new_node->get_value()<<endl;
            new_node=new_node->prev;
        }
    }
}

int Stack_C :: add(){
    int ele1=pop();
    int ele2=pop();
    int addition=ele1+ele2;
    push(addition);
    return addition;
}

int Stack_C :: subtract(){
    int ele1=pop();
    int ele2=pop();
    int subt=ele2-ele1;  //Ek baar check ki ele1-ele2 hai yaa ye sahi hai
    push(subt);
    return subt;
}

int Stack_C :: multiply(){
    int ele1=pop();
    int ele2=pop();
    int mul=ele2*ele1;
    push(mul);
    return mul;    
}

int Stack_C :: divide(){
    int ele1=pop();
    int ele2=pop();
    if (ele1==0){
        throw runtime_error("Divide by Zero Error");
    }
    int result=floor(static_cast<double>(ele2)/static_cast<double>(ele1));
    push(result);
    return result;   
}

List* Stack_C :: get_stack(){
    return stk;
}

int Stack_C :: get_size(){
    Node* nd=stk->get_head()->next;
    int count=0;
    while (!nd->is_sentinel_node()){
        // cout<<nd->get_value()<<endl;
        count++;
        nd=nd->next;
    }
    // cout<<"size ka function pura karna"<<endl;
    return count;
}


int main() {
    // Write C++ code here
    Stack_C stkobj;
    int i=0;
    while (i<1){
        string s;
        cout<<"Enter string"<<endl;
        cin>>s;
        if (s=="add"){
            cout<<stkobj.add()<<endl;
        }
        else if (s=="push"){
            int num;
            cin>>num;
            stkobj.push(num);
        }
        else if (s=="subtract"){
            cout<<stkobj.subtract()<<endl;
        }
        else if (s=="divide"){
            cout<<stkobj.divide()<<endl;
        }
        else if (s=="multiply"){
            cout<<stkobj.multiply()<<endl;
        }
        i++;
        // stkobj.push(i+2);
        // i++;
    }
    // cout<<stkobj.get_size()<<endl;
    cout<<endl;
    cout<<"Stack is :"<<endl;
    stkobj.print_stack(true);
    cout<<endl;
    // cout<<"Elements at index 3: "<<endl;
    try{
        cout<<stkobj.pop()<<endl;
        cout<<stkobj.pop()<<endl;
    }catch(...){
        cout<<"Error is thrown"<<endl;
    }

    // cout<<stkobj.delete_tail()<<endl;
    // cout<<stkobj.get_size()<<endl;
    // Node* curr_node=stkobj.get_head();
    // cout<<endl;
    // while (i<9){
    //     cout<<curr_node->get_value()<<endl;
    //     curr_node=curr_node->next;
    //     i++;
    // }
}
