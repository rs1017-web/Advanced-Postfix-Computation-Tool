#include "node.h"
#include <iostream>
using namespace std;

int main(){
    // Node* newnd = new Node();
    int i=0;
    while (i<4){
        // ndobj.insert(2);
        i++;
    }
}