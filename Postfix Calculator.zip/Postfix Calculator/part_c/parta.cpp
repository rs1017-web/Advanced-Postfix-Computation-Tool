#include "stack_c.h"
#include <cmath>
#include <iostream>
using namespace std;

// push 2
// push 10                  stack:  top                                             bottom
// push -6                             -7   -9  11 5 4   -15   4  -6  10  2
// push 4
// push -15                 output :  -19   4  -6  10  2
// push 4
// push 5
// push 11
// push -9
// push -7
// add
// add
// add
// subtract
// subtract
// divide
// divide
// multiply
// multiply



int main(){
    Stack_C stkobj;
    int i=0;
    while (i<19){
        string s;
        cout<<"Enter string"<<endl;
        cin>>s;
        if (s=="add"){
            cout<<stkobj.add()<<endl;
        }
        else if (s=="push"){
            int num;
            cin>>num;
            stkobj.push(num);
        }
        else if (s=="subtract"){
            cout<<stkobj.subtract()<<endl;
        }
        else if (s=="divide"){
            cout<<stkobj.divide()<<endl;
        }
        else if (s=="multiply"){
            cout<<stkobj.multiply()<<endl;
        }
        i++;
    }
}