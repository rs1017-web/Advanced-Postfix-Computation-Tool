#include "list.h"
#include <cmath>
#include <iostream>
using namespace std;

int main(){
    List lstobj;
    int i=0;
    while (i<4){
        lstobj.insert(2);
        i++;
    }
}

