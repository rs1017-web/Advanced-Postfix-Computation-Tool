#include "stack_c.h"
#include <stdexcept>
#include <iostream>
using namespace std;


Stack_C::Stack_C(){
    try{
        stk = new List();
    } catch (const bad_alloc&){
        throw runtime_error("Out of Memory");
    }
}


Stack_C :: ~Stack_C(){
    delete stk;
}


void Stack_C :: push (int data){
    stk->insert(data);
}

int Stack_C :: pop(){
    // List lstobj;
    // int size = stk->get_size();
    // if (size==0){
    //     throw runtime_error("Empty Stack");
    // }
    int ele = stk->delete_tail(); 
    return ele;
    // List listobj;
    // int ele=listobj.delete_tail(); 
    // return ele;
}

int Stack_C :: get_element_from_top(int idx){
    Node* curr_node=stk->get_head()->next;  //yha bhi change kiya hai.
    Node* sentinel_tail;
    while (!curr_node->is_sentinel_node()){
        curr_node=curr_node->next;
        if (curr_node->is_sentinel_node()){
            sentinel_tail=curr_node;
            break;
        }
    }
    Node* new_node=sentinel_tail->prev;
    int count=0;
    while (!new_node->is_sentinel_node()){
        if (count==idx){
            return new_node->get_value();
        }
        // cout<<new_node->get_value()<<endl;
        count++;
        new_node=new_node->prev;
    }
    throw runtime_error("Index out of range");
}


int Stack_C :: get_element_from_bottom(int idx){
    // List listobj;
    Node* curr_node=stk->get_head()->next;
    int count=0;
    while (!curr_node->is_sentinel_node()){
        if (count==idx){
            return curr_node->get_value();
        }
        curr_node=curr_node->next;
        count++;
    }
    throw runtime_error("Index out of range");   
}

void Stack_C :: print_stack (bool top_or_bottom){
    if (!top_or_bottom){
        Node* curr_node=stk->get_head()->next;
        while (curr_node!=NULL){
            cout<<curr_node->get_value()<<endl;
            curr_node=curr_node->next;
        }
    }
    else{
        Node* curr_node=stk->get_head()->next;     //yha bhi change kiya hai.
        Node* sentinel_tail;
        while (!curr_node->is_sentinel_node()){
            curr_node=curr_node->next;
            if (curr_node->is_sentinel_node()){
                sentinel_tail=curr_node;
                break;
            }
        }
        Node* new_node=sentinel_tail->prev;
        while (!new_node->is_sentinel_node()){
            cout<<new_node->get_value()<<endl;
            new_node=new_node->prev;
        }
        // cout<<"tail se start karna hai"<<endl;
    }
}

int Stack_C :: add(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int addition=ele1+ele2;
    push(addition);
    return addition;
}

int Stack_C :: subtract(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int subt=ele2-ele1;  //Ek baar check ki ele1-ele2 hai yaa ye sahi hai
    push(subt);
    return subt;
}

int Stack_C :: multiply(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int mul=ele2*ele1;
    push(mul);
    return mul;    
}

int Stack_C :: divide(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    if (ele1==0){
        throw runtime_error("Divide by Zero Error");
    }
    int result=ele2/ele1;
    if (result<=0 && ele2 % ele1 !=0 && (ele1<0 || ele2<0)){
        result--;
    }
    push(result);
    return result;  
}

List* Stack_C :: get_stack(){
    return stk;
}

int Stack_C :: get_size(){
    Node* nd=stk->get_head()->next;
    int count=0;
    while (!nd->is_sentinel_node()){
        // cout<<nd->get_value()<<endl;
        count++;
        nd=nd->next;
    }
    // cout<<"size ka function pura karna"<<endl;
    return count;
}
