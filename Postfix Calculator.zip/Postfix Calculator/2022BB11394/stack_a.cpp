#include "stack_a.h"
#include <stdexcept>
#include <iostream>
using namespace std;

// push 2
// push 10                  stack:  top                                             bottom
// push -6                           -19   4  -6  10  2
// push 4
// push -15
// push 4
// push 5
// push 11
// push -9
// push -7
// add
// add
// add
// subtract
// subtract
// divide
// divide
// multiply
// multiply


Stack_A:: Stack_A(){
    size=0;      //NOT SURE
}

int* Stack_A :: get_stack(){
    return stk;   //NOT SURE
}

int Stack_A :: get_size(){
    return size;
}

void Stack_A :: push(int data){
    if (size==1024){
        throw std::runtime_error("Stack Full");
    }
    else{
        stk[size]=data;
        size++;
    }
}

int Stack_A :: pop(){
    if (size==0){
        throw std::runtime_error("Empty Stack");
    }
    else{
        int element=stk[size-1];
        stk[size-1]=0;
        size--;
        return element;
    }
}

int  Stack_A :: get_element_from_top(int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[size-idx-1];
        return element;
    }
}

int Stack_A :: get_element_from_bottom(int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[idx];
        return element;
    }
}

void Stack_A :: print_stack(bool top_or_bottom){
    if (top_or_bottom==true){
        int count=size;
        while (count>0){
            cout<<stk[count-1]<<endl;
            count--;
        }
        return;
    }
    int count=0;
    while (count<size){
        cout<<stk[count]<<endl;
        count++;
    }
}

int Stack_A :: add(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int result=ele1+ele2;
    push(result);
    return result;
}

int Stack_A :: subtract(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int result=ele2-ele1;
    push(result);
    return result;
}

int Stack_A :: multiply(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(...){
        throw runtime_error("Not Enough Arguments");
    }
    int result=ele2*ele1;
    push(result);
    return result; 
}

int Stack_A :: divide(){
    int ele1;
    int ele2;
    try{
        ele1=pop();
        ele2=pop();
    }catch(const std::runtime_error& e){
        throw runtime_error("Not Enough Arguments");
    }
    if (ele1==0){
        throw runtime_error("Divide by Zero Error");
    }
    int result=ele2/ele1;
    if (result<=0 && ele2 % ele1 !=0 && (ele1<0 || ele2<0)){
        result--;
    }
    push(result);
    return result;
}

