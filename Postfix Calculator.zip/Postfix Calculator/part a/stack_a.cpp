#include "stack_a.h"
#include <cmath>
#include <iostream>
using namespace std;

Stack_A:: Stack_A(){
    size=0;
}

int* Stack_A :: get_stack(){
    return stk;
}

int Stack_A :: get_size(){
    return size;
}

void Stack_A :: push(int data){
    if (size==1024){
        throw std::runtime_error("Stack Full");
    }
    else{
        stk[size]=data;
        size++;
    }
}

int Stack_A :: pop(){
    if (size==0){
        throw std::runtime_error("Empty Stack");
    }
    else{
        int element=stk[size-1];
        stk[size-1]=0;
        size--;
        return element;
    }
}

int  Stack_A :: get_element_from_top(int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[size-idx-1];
        return element;
    }
}

int Stack_A :: get_element_from_bottom(int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[idx];
        return element;
    }
}

void Stack_A :: print_stack(bool top_or_bottom){
    if (top_or_bottom==true){
        int count=size;
        while (count>0){
            cout<<stk[count-1]<<endl;
            count--;
        }
        return;
    }
    int count=0;
    while (count<size){
        cout<<stk[count]<<endl;
        count++;
    }
}

int Stack_A :: add(){
    int ele1=pop();
    int ele2=pop();
    int result=ele1+ele2;
    push(result);
    return result;
}

int Stack_A :: subtract(){
    int ele1=pop();
    int ele2=pop();
    int result=ele2-ele1;
    push(result);
    return result;
}

int Stack_A :: multiply(){
    int ele1=pop();
    int ele2=pop();
    int result=ele2*ele1;
    push(result);
    return result; 
}

int Stack_A :: divide(){
    int ele1=pop();
    int ele2=pop();
    int result=ele1/ele2;
    push(floor(static_cast<double>(result)));
    return result; 
}