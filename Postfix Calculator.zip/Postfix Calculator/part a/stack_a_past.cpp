#include <iostream>
#include <cmath>
using namespace std;

// #pragma once 

/* PART A */
/* Stacks using Fixed Size Arrays */

class Stack_A {
private:
    int stk[1024]; // The fixed size array
    int size; // Number of elements in the stack

public: 
    // Constructor
    Stack_A();

    void push(int data){
        if (size==1024){
            throw std::runtime_error("Stack Full");
        }
        else{
            stk[size]=data;
            size++;
        }
    }


    int pop(){
        if (size==0){
            throw std::runtime_error("Empty Stack");
        }
        else{
            int element=stk[size-1];
            stk[size-1]=0;
            size--;
            return element;
        }
    }

// stack =  14 15 16  17  23 27 19  28  35  48  75  99  25
// idx   =  0   1  2  3   4  5   6  7   8   9   10  11  12
// int idx=3

    int get_element_from_top(int idx){
        if (idx>=size || idx<0){
            throw runtime_error("Index out of range");
        }
        else{
            int element=stk[size-idx-1];
            return element;
        }
    }

    int get_element_from_bottom(int idx){
        if (idx>=size || idx<0){
            throw runtime_error("Index out of range");
        }
        else{
            int element=stk[idx];
            return element;
        }
    }

    void print_stack(bool top_or_bottom){
        if (top_or_bottom==true){
            int count=size;
            while (count--){
                cout<<stk[count-1]<<endl;
            }
            return;
        }
        int count=0;
        while (count<size){
            cout<<stk[count]<<endl;
            count++;
        }
    }

    int add(){
        int ele1=pop();
        int ele2=pop();
        int result=ele1+ele2;
        push(result);
        return result;
    }

    int subtract(){
        int ele1=pop();
        int ele2=pop();
        int result=ele2-ele1;
        push(result);
        return result;     
    }

    int multiply(){
        int ele1=pop();
        int ele2=pop();
        int result=ele2*ele1;
        push(result);
        return result;    
    }

    int divide(){
        int ele1=pop();
        int ele2=pop();
        int result=ele1/ele2;
        push(floor(static_cast<double>(result)));
        return result;  
    }

    int* get_stack() // Get a pointer to the array
    {
        return &stk[0];
    }

    int get_size(){
        return size;
    } // Get the size of the stack

};