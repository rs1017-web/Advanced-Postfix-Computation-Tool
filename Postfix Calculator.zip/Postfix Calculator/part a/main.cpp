#include "stack_a.h"
#include <cmath>
#include <iostream>
using namespace std;

int main(){
    Stack_A stkobj;
    stkobj.push(23);
    stkobj.push(12);
    cout << stkobj.add() << std::flush;
}

