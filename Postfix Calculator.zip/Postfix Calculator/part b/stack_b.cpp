#include "stack_b.h"
#include <iostream>
using namespace std;

Stack_B :: Stack_B(){
    stk=new int[1024];
    capacity=1024;
}

Stack_B :: ~Stack_B(){
    delete[] stk;
}

void Stack_B :: push(int data){
    if (size==capacity){
        int * temp_stk=new int[2*capacity];
        for (int i=0;i<size;i++){
            temp_stk[i]=stk[i];
        }
        temp_stk[size]=data;
        delete[] stk;
        stk=temp_stk;
        temp_stk=nullptr;
        capacity*=2;
        size++;
        return;
    }
    stk[size-1]=data;
    size++;
}

int Stack_B :: pop(){
    if (size==0){
        throw runtime_error("Empty Stack");
    }
    if (size-1<=1024){
        int * temp_stk=new int[1024];
        for (int i=0;i<size;i++){
            temp_stk[i]=stk[i];
        }
        delete[] stk;
        stk=temp_stk;
        temp_stk=nullptr;
        capacity=1024;
        int element=stk[size-1];
        stk[size-1]=0;
        size--;
        return element;
    }
    int element=stk[size-1];
    stk[size-1]=0;
    size--;
    return element;
}

int Stack_B :: get_element_from_top(int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[size-idx-1];
        return element;
    } 
}

int Stack_B :: get_element_from_bottom (int idx){
    if (idx>=size || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        int element=stk[idx];
        return element;
    }
}

void Stack_B :: print_stack (bool top_or_bottom){
    if (top_or_bottom==true){
        int count=size;
        while (count--){
            cout<<stk[count-1]<<endl;
        }
        return;
    }
    int count=0;
    while (count<size){
        cout<<stk[count]<<endl;
        count++;
    }
}

int Stack_B :: add(){
    int ele1=pop();
    int ele2=pop();
    int result=ele1+ele2;
    push(result);
    return result;
}

int Stack_B :: subtract(){
    int ele1=pop();
    int ele2=pop();
    int result=ele2-ele1;
    push(result);
    return result;
}

int Stack_B :: multiply(){
    int ele1=pop();
    int ele2=pop();
    int result=ele2*ele1;
    push(result);
    return result; 
}

int Stack_B :: divide(){
    int ele1=pop();
    int ele2=pop();
    int result=ele1/ele2;
    push(floor(static_cast<double>(result)));
    return result;
}

int* Stack_B :: get_stack(){
    return stk;
}

int Stack_B :: get_size(){
    return size;
}