#pragma once 
#include <iostream>
using namespace std;
/* PART B */
/* Dynamic Stacks */

class Stack_B {
private:
    int* stk; // The dynamic array
    int size; // Number of elements in the stack
    int capacity; // Capacity of the stack

public: 
    // Constructor
    Stack_B(){
        stk=new int[1024];
        capacity=1024;
    }

    // Destructor
    ~Stack_B(){
        delete[] stk;
    }
    
    void push(int data){
        if (size==capacity){
            int * temp_stk=new int[2*capacity];
            for (int i=0;i<size;i++){
                temp_stk[i]=stk[i];
            }
            temp_stk[size]=data;
            delete[] stk;
            stk=temp_stk;
            temp_stk=nullptr;
            capacity*=2;
            size++;
            return;
        }
        stk[size-1]=data;
        size++;
    }

    int pop(){
        if (size==0){
            throw runtime_error("Empty Stack");
        }
        if (size-1<=1024){
            int * temp_stk=new int[1024];
            for (int i=0;i<size;i++){
                temp_stk[i]=stk[i];
            }
            delete[] stk;
            stk=temp_stk;
            temp_stk=nullptr;
            capacity=1024;
            int element=stk[size-1];
            stk[size-1]=0;
            size--;
            return element;
        }
        int element=stk[size-1];
        stk[size-1]=0;
        size--;
        return element;
    }

    int get_element_from_top(int idx){
        if (idx>=size || idx<0){
            throw runtime_error("Index out of range");
        }
        else{
            int element=stk[size-idx-1];
            return element;
        }   
    }

    int get_element_from_bottom(int idx){
        if (idx>=size || idx<0){
            throw runtime_error("Index out of range");
        }
        else{
            int element=stk[idx];
            return element;
        }
    }

    void print_stack(bool top_or_bottom){
        if (top_or_bottom==true){
            int count=size;
            while (count--){
                cout<<stk[count-1]<<endl;
            }
            return;
        }
        int count=0;
        while (count<size){
            cout<<stk[count]<<endl;
            count++;
        }
    }

    int add(){
        int ele1=pop();
        int ele2=pop();
        int result=ele1+ele2;
        push(result);
        return result;
    }

    int subtract(){
        int ele1=pop();
        int ele2=pop();
        int result=ele2-ele1;
        push(result);
        return result;
    }

    int multiply(){
        int ele1=pop();
        int ele2=pop();
        int result=ele2*ele1;
        push(result);
        return result; 
    }

    int divide(){
        int ele1=pop();
        int ele2=pop();
        int result=ele1/ele2;
        push(floor(static_cast<double>(result)));
        return result;
    }

    int* get_stack() // Get a pointer to the array
    {
        return stk;
    }

    int get_size() // Get the size of the stac
    {
        return size;
    }

};